// src/middleware/auth.js
export function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: "ยังไม่ได้ล็อกอิน" });
  }
  next();
}

export function requireAdmin(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: "ยังไม่ได้ล็อกอิน" });
  }
  if (!req.session.user.isAdmin) {
    return res.status(403).json({ error: "ต้องเป็นแอดมินเท่านั้น" });
  }
  next();
}

/** Allows the request through if the caller owns the server OR is admin. */
export function isOwnerOrAdmin(user, server) {
  return user.isAdmin || server.ownerId === user.discordId;
}
