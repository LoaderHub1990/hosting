// js/router.js
// -----------------------------------------------------------------------
// Tiny hash router. Routes look like:
//   #/                                -> server list
//   #/server/e59f29fe/files           -> file manager, root
//   #/server/e59f29fe/files/plugins   -> file manager, inside "plugins"
//   #/server/e59f29fe/edit/commands.sh-> file editor for commands.sh
//   #/server/e59f29fe/commands        -> command console
// -----------------------------------------------------------------------

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, ""); // strip "#/" or "#"
  const parts = raw.split("/").filter(Boolean);

  if (parts[0] === "login") return { name: "login" };
  if (parts[0] === "admin") return { name: "admin" };

  if (parts[0] === "server" && parts[1]) {
    const serverId = parts[1];
    const section = parts[2] ?? "files";
    const rest = parts.slice(3).join("/"); // remaining path (file path, etc.)

    if (section === "files") return { name: "files", serverId, path: rest };
    if (section === "edit")  return { name: "edit",  serverId, path: rest };
    if (section === "packages") return { name: "packages", serverId };
    if (section === "commands") return { name: "commands", serverId };
  }

  return { name: "servers" };
}

export function initRouter(onChange) {
  const fire = () => onChange(parseHash());
  window.addEventListener("hashchange", fire);
  fire(); // initial render
}

export function goTo(hash) {
  location.hash = hash;
}

export const routes = {
  servers: () => "#/",
  login: () => "#/login",
  admin: () => "#/admin",
  files: (serverId, path = "") => `#/server/${serverId}/files${path ? "/" + path : ""}`,
  edit: (serverId, path) => `#/server/${serverId}/edit/${path}`,
  packages: (serverId) => `#/server/${serverId}/packages`,
  commands: (serverId) => `#/server/${serverId}/commands`,
};
