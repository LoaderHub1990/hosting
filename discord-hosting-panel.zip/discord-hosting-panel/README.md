# Discord Bot Hosting Panel

เว็บแผงควบคุมสำหรับ login ด้วย Discord แล้วให้แอดมินสร้าง "เซิร์ฟเวอร์บอท" ให้แต่ละ user จัดการเอง — ไฟล์, Node packages, start/stop, console

## ✨ อัปเดตล่าสุด
- **ระบบจำกัดสเปค (CPU% / Memory MB)** — หน้าแอดมินตั้งค่าได้ตอนสร้างเซิร์ฟเวอร์ และแก้ทีหลังได้ (ช่อง "บันทึกสเปค" ในตารางเซิร์ฟเวอร์ทั้งหมด) หน่วยความจำบังคับจริงด้วย `--max-old-space-size` + watchdog ที่ฆ่าโปรเซสถ้า RSS เกิน limit ไปมาก, CPU จำกัดแบบ soft-throttle (สั่งพักโปรเซสสั้นๆ ด้วย SIGSTOP/SIGCONT เวลาใช้เกิน limit) — ไม่ต้องพึ่ง Docker/root
- **ช่อง Address** — แต่ละเซิร์ฟเวอร์มี "พอร์ต" ของตัวเอง โชว์เป็น `โฮสต์:พอร์ต` ในหน้าคำสั่ง เหมือนช่อง Address ของ Pterodactyl
- **หน้าคำสั่งดีไซน์ใหม่** — แถบสถานะใหญ่ด้านบนพร้อมปุ่ม Start/Restart/Stop, การ์ดสถานะขนาดใหญ่ขึ้น (Address, Uptime, CPU/Memory พร้อม `/ limit`, Disk, Network Inbound/Outbound) และกราฟเส้นแบบเรียลไทม์ (CPU / Memory / Network) อัปเดตทุก 1.5 วินาทีจากข้อมูลจริง ไม่ใช่ mock
- **หน้าล็อกอินใหม่** — ดีไซน์การ์ดกลางจอ พื้นหลังไล่สีเคลื่อนไหวเบาๆ แบบสมูท
- **ลากไฟล์วางเพื่ออัปโหลด** — หน้า "ไฟล์" ลากไฟล์จากเครื่องมาวางในกล่องได้เลย (หรือกดปุ่ม "อัปโหลดไฟล์" เลือกจากเครื่อง) มี progress bar ระหว่างอัปโหลด
- **สถานะสดขณะรัน** — หน้า "คำสั่ง" มีการ์ดแสดง CPU / Memory / Disk / Uptime อัปเดตทุก 1.5 วินาที พร้อมปุ่ม Start / Restart / Stop สไตล์เดียวกับแผงโฮสต์ทั่วไป
- **npm install แบบเรียลไทม์** — หน้า "Packages" มีปุ่มเพิ่ม package ยอดนิยมแบบด่วน (discord.js, axios, dotenv, ...) และ log ของ npm install จะทยอยขึ้นระหว่างติดตั้งแทนที่จะโผล่มาทีเดียวตอนจบ
- ดีไซน์ปรับให้ดูพรีเมียมขึ้น (เงา, ไล่สีพื้นหลังจางๆ, animation เล็กๆ น้อยๆ) โดยยังใช้ธีมสีเดิม

> ต้องรัน `npm install` ใหม่ในโฟลเดอร์ `backend/` ก่อนสตาร์ท เพราะมีการเพิ่ม dependency ใหม่ (`multer` สำหรับอัปโหลดไฟล์, `pidusage` สำหรับอ่านค่า CPU/Memory ของโปรเซสบอท) — ฟีเจอร์วัดพื้นที่ดิสก์ใช้คำสั่ง `du` ของระบบ ซึ่งมีอยู่แล้วบน Linux/macOS ปกติ (บน Windows จะ fallback ไปคำนวณเองแทน) — ระบบจำกัด CPU (SIGSTOP/SIGCONT) และ Network graph (`/proc/net/dev`) ก็ใช้ได้เฉพาะบน Linux เท่านั้น (VPS ทั่วไปเป็น Linux อยู่แล้ว)

---

```
discord-hosting-panel/
├── backend/     ← Express API + process manager (ต้องรันด้วย Node.js)
└── frontend/    ← หน้าเว็บ (เสิร์ฟให้อัตโนมัติโดย backend)
```

---

## 1. สร้าง Discord Application

1. ไปที่ https://discord.com/developers/applications → **New Application**
2. เข้าไปที่แท็บ **OAuth2** → คัดลอก **Client ID** และ **Client Secret**
3. ในแท็บเดียวกัน ที่ช่อง **Redirects** ให้เพิ่ม:
   - ตอนทดสอบเครื่องตัวเอง: `http://localhost:3000/api/auth/discord/callback`
   - ตอนขึ้น VPS จริง: `https://โดเมนของคุณ/api/auth/discord/callback`

## 2. ตั้งค่า backend

```bash
cd backend
cp .env.example .env
```

แก้ไข `.env`:

```
DISCORD_CLIENT_ID=วางค่าจริง
DISCORD_CLIENT_SECRET=วางค่าจริง
DISCORD_REDIRECT_URI=http://localhost:3000/api/auth/discord/callback   (หรือโดเมนจริงตอน deploy)
SESSION_SECRET=สุ่มสตริงยาวๆ ห้ามใช้ค่า default
ADMIN_DISCORD_IDS=user_id_ของคุณ
```

วิธีหา Discord user id ของตัวเอง: Discord → Settings → Advanced → เปิด Developer Mode → คลิกขวาชื่อตัวเอง → Copy User ID

## 3. รัน

```bash
cd backend
npm install
npm start
```

เปิด `http://localhost:3000` → กด "เข้าสู่ระบบด้วย Discord" → login ด้วยบัญชีที่อยู่ใน `ADMIN_DISCORD_IDS` → จะเห็นเมนู "แอดมิน" ที่แถบซ้าย

## 4. ใช้งาน

1. **แอดมิน** → เมนู "แอดมิน" → สร้างเซิร์ฟเวอร์ใหม่ (ผู้ใช้ปลายทางต้อง login เข้าเว็บอย่างน้อย 1 ครั้งก่อน ถึงจะเลือกเป็นเจ้าของได้)
2. ระบบจะสร้างโฟลเดอร์ `backend/data/servers/<id>/` พร้อม `package.json` + `index.js` ตัวอย่าง (โครง discord.js เปล่าๆ ให้ผู้ใช้ไปแก้ token/โค้ดเอง)
3. **เจ้าของเซิร์ฟเวอร์** → เข้า "ไฟล์" แก้โค้ด/ลากไฟล์จากเครื่องมาวางเพื่ออัปโหลด, "Packages" เพิ่ม/ลบ npm package (มีปุ่มเพิ่มด่วนให้ด้วย) แล้วกด npm install จริง, "คำสั่ง" ดูสถานะสด (CPU/Memory/Disk/Uptime) + console + พิมพ์คำสั่งเอง, ปุ่ม Start/Restart/Stop

---

## Deploy ขึ้น VPS จริง

1. ติดตั้ง Node.js 18+ บน VPS (`nvm install 18` หรือผ่าน package manager)
2. Clone/อัปโหลดโปรเจกต์นี้ขึ้น VPS
3. ตั้งค่า `.env` ให้ `DISCORD_REDIRECT_URI` เป็นโดเมนจริง (ต้องตรงกับที่ตั้งในหน้า Discord Developer Portal เป๊ะๆ)
4. ใช้ **pm2** ให้รันค้างและ auto-restart:
   ```bash
   npm install -g pm2
   cd backend && npm install
   pm2 start src/server.js --name discord-panel
   pm2 save
   pm2 startup   # ทำตามคำสั่งที่ขึ้นมาเพื่อให้รันตอนบูตเครื่องด้วย
   ```
5. ตั้ง **nginx** เป็น reverse proxy + ใส่ HTTPS ผ่าน Let's Encrypt (`certbot`) — อย่าเปิดพอร์ต 3000 ตรงๆ ให้สาธารณะ
6. ใน `backend/src/server.js` เปลี่ยน `cookie.secure: false` → `true` เมื่อรันหลัง HTTPS แล้ว

---

## ⚠️ เรื่องความปลอดภัยที่ต้องรู้ก่อนเปิดให้คนอื่นใช้จริง

ระบบนี้ให้ user แก้ไฟล์ + เพิ่ม npm package + สั่งรันโค้ด (`node index.js`, `npm install`) **บนเครื่อง VPS เดียวกับ backend เอง** ซึ่งหมายความว่า:

- user ที่ตั้งใจร้ายสามารถใส่โค้ดอะไรก็ได้ลงไฟล์ แล้วรันโค้ดนั้นด้วยสิทธิ์เดียวกับตัว backend
- `npm install` ของ package ที่มี malicious postinstall script ก็รันโค้ดได้ทันทีตอนติดตั้ง
- ถ้า backend รันด้วยสิทธิ์สูง (เช่น root) หรือไฟล์ทุกเซิร์ฟเวอร์เก็บโดยไม่มีการกั้นสิทธิ์ระหว่างกัน user คนหนึ่งอาจกระทบ/อ่านข้อมูลของอีกคนได้

**สำหรับใช้ส่วนตัว/กับเพื่อนที่ไว้ใจได้จริงๆ** — ระบบตอนนี้เพียงพอ

**ถ้าจะเปิดให้คนทั่วไปสมัครใช้** ควรทำเพิ่มก่อน:
- รันแต่ละ server ใน Docker container แยกกัน (จำกัด CPU/RAM/network ต่อ container)
- รัน backend ด้วย user ที่ไม่มีสิทธิ์ root และไม่มีสิทธิ์เขียนไฟล์นอก `data/servers/`
- จำกัดจำนวน/ขนาดไฟล์ที่ upload ได้ และ rate-limit การเรียก API
- พิจารณา whitelist เฉพาะ npm package ที่อนุญาต แทนที่จะปล่อยให้ติดตั้งอะไรก็ได้

### เรื่องการจำกัดสเปค (CPU% / Memory MB) ที่ควรรู้

ระบบนี้ **ไม่ได้ใช้ Docker/cgroups** จึงจำกัดสเปคแบบ "ทำเท่าที่ทำได้โดยไม่ต้องใช้ root":
- **Memory**: บังคับสองชั้น — (1) สั่ง Node ด้วย `--max-old-space-size` ให้ V8 heap โตเกิน limit ไม่ได้ (2) มี watchdog เช็ค RSS จริงทุก 2 วินาที ถ้าเกิน limit ไปเยอะ (>15%) จะฆ่าโปรเซสทันทีเหมือน OOM-kill ของ container — เชื่อถือได้ในระดับหนึ่ง
- **CPU**: เป็น "soft-throttle" — watchdog จะสั่งพักโปรเซส (`SIGSTOP`) สั้นๆ แล้วปลุกต่อ (`SIGCONT`) เวลาใช้ CPU เกิน limit เพื่อดึงค่าเฉลี่ยลงมา **ไม่ใช่ hard quota แบบ cgroup จริง** ถ้าต้องการจำกัด CPU แบบเข้มงวดจริงๆ ให้พิจารณาย้ายไป Docker + `--cpus`
- ค่า limit ที่แอดมินตั้งไว้ใช้ได้ทันทีสำหรับการเช็ค RSS/soft-throttle (ไม่ต้อง restart) แต่ค่า `--max-old-space-size` (heap) จะมีผลตอน start ครั้งถัดไปเท่านั้น

### เรื่องกราฟ Network (Inbound/Outbound) ที่ควรรู้

ตัวเลขกราฟ Network ในหน้าคำสั่งเป็น **network throughput ของทั้งเครื่อง VPS** (อ่านจาก `/proc/net/dev`) ไม่ใช่ของบอทตัวนั้นตัวเดียว เพราะการแยก network I/O ต่อโปรเซสแบบแม่นยำต้องใช้ network namespace (Docker) ซึ่ง setup แบบ spawn ตรงๆ นี้ไม่มี — ถ้ามีบอทหลายตัวรันพร้อมกัน ตัวเลขนี้จะเป็นผลรวมของทุกตัว

## ระบบกัน Ctrl+U / คลิกขวา (`frontend/js/security.js`)

เป็นแค่การกันกวนคนทั่วไปที่อยากดู source code ผ่านเมนูปกติ **ไม่ใช่ความปลอดภัยจริง** — คนที่ตั้งใจดูโค้ดยังเข้าถึงได้ผ่าน network tab หรือปิด JavaScript ก่อนโหลดหน้าเว็บ ห้ามฝาก API key/secret ไว้ใน frontend code เด็ดขาด (secret ทั้งหมดใน backend อยู่ใน `.env` ซึ่งไม่ถูกส่งไปหา browser อยู่แล้ว)
